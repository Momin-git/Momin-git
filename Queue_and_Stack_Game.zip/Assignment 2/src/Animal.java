//creating Animal Superclass and subclasses with getters for score
public  class Animal implements Scoreable {
    @Override
    public int getScore() {
        return 0;
    }
}

class Bird extends Animal {
    AnimalType Bird = AnimalType.Bird;
    private int score = Bird.getScore() * 5;

    @Override
    public int getScore() {
        return score;
    }
}


class Dog extends Animal {
    AnimalType Dog = AnimalType.Dog;
    private int score = Dog.getScore() * 5;

    @Override
    public int getScore() {
        return score;
    }
}

class Fish extends Animal {
        AnimalType Fish = AnimalType.Fish;
        private int score = Fish.getScore() * 5;

        @Override
        public int getScore() {
            return score;
        }
    }

class Frog extends Animal {
        AnimalType Frog = AnimalType.Frog;
        private int score = Frog.getScore() * 5;

        @Override
        public int getScore() {
            return score;
        }
    }

class Swan extends Animal {
        AnimalType Swan = AnimalType.Swan;
        private int score = Swan.getScore() * 5;

        @Override
        public int getScore() {
            return score;
        }
    }

