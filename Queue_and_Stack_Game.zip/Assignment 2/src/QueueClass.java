// make 2 teams (queues) of 6 people to play a game
// each team has one queue of players and one queue of animals
//there is a stack of 12 animals and it is used to populate the animal queues of 6 for each team
// round 1. select a random number 0,10,20,30,40,50,60,70,80,90 for each team
// round 2. if score from round one is greater or equal to 60, give an animal with a value that is a multiple of 5.
// compare the results to find winning team
// print results of winning team to file
//Create a class called Game which will implement the main() method



import java.util.Iterator;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Queue;

//creating queue class which implements queue from collections
public abstract class QueueClass implements Queue<Object> {

//overriding methods

    @Override
    public int size() {
        return 0;
    }

    @Override
    public Iterator<Object> iterator() {
        return null;
    }

    @Override
    public boolean add(Object o) {
        return false;
    }

    @Override
    public boolean remove(Object o) {
        return false;
    }

    @Override
    public boolean addAll(Collection<?> c) {
        return false;
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        return false;
    }

    @Override
    public void clear() {

    }

    @Override
    public Object remove() {
        return null;
    }

    @Override
    public Object poll() {
        return null;
    }

    @Override
    public Object peek() {
        return null;
    }
}

