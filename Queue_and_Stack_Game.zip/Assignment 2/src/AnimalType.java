//animaltype enumerator
public enum AnimalType {
    Bird(1), Dog(2), Fish(3), Frog(4), Swan(5);
    private int score;

    AnimalType(int s) {
        score = s;
    }


    public int getScore() {
        return score;
    }
}
