/*Name: Momin Butt
  Assignment: Assignment 2
  Program: Information Systems Security
  Description:
 // make 2 teams (queues) of 6 people to play a game
// each team has one queue of players and one queue of animals
//there is a stack of 12 animals and it is used to populate the animal queues of 6 for each team
// round 1. select a random number 0,10,20,30,40,50,60,70,80,90 for each team
// round 2. if score from round one is greater or equal to 60, give an animal with a value that is a multiple of 5.
// compare the results to find winning team
// print results of winning team to file
//Create a class called Game which will implement the main() method

*/

import java.io.*;
import java.security.SecureRandom;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import java.util.Queue;
import java.util.Stack;
import java.io.FilePermission;


import static java.util.Collections.shuffle;

public class Game {
    public static void main(String[] args) {
        //initializing variables
        final String filepath = "C:\\temp";
        int rand1;
        int rand2;
        Queue<Object> Players1 = new LinkedList<>();
        Queue<Object> Players2 = new LinkedList<>();
        Queue<Object> Animals1 = new LinkedList<>();
        Queue<Object> Animals2 = new LinkedList<>();
        Queue<Object> Winners = new LinkedList<>();
        Stack<Object> AnimalStack = new Stack<>();

        //fills Players Queue with 6 Team Members
        Players1.add(new Employee());
        Players1.add(new Admin());
        Players1.add(new Staff());
        Players1.add(new Faculty());
        Players1.add(new Employee());
        Players1.add(new Admin());

        //fills players2 queue with 6 team members
        Players2.add(new Employee());
        Players2.add(new Admin());
        Players2.add(new Staff());
        Players2.add(new Faculty());
        Players2.add(new Employee());
        Players2.add(new Admin());


        //fills animal stack with 12 animals and then shuffles the stack
        AnimalStack.push(new Bird());
        AnimalStack.push(new Dog());
        AnimalStack.push(new Fish());
        AnimalStack.push(new Frog());
        AnimalStack.push(new Swan());
        AnimalStack.push(new Bird());
        AnimalStack.push(new Dog());
        AnimalStack.push(new Fish());
        AnimalStack.push(new Frog());
        AnimalStack.push(new Swan());
        AnimalStack.push(new Bird());
        AnimalStack.push(new Dog());
        shuffle(AnimalStack);






        // create a list of elements 0,10,20,30,40,50,60,70,80,90

        List<Integer> randomScores = new ArrayList<Integer>();


        // assign a value 0-90 inclusive to each element
        for (int i = 0; i < 10; i++) {
            randomScores.add(i * 10);
        }

        //round 1. select a random number 0,10,20,30,40,50,60,70,80,90 for each team
        shuffle(randomScores);
        rand1 = randomScores.get(0);
        shuffle(randomScores);
        rand2 = randomScores.get(0);

        //print both teams scores
        System.out.println("Round 1:");
        System.out.printf("Team 1 Score: %d\n", rand1);
        System.out.printf("Team 2 Score: %d\n", rand2);
        System.out.println("Round 2:");

        //if team 1 score is greater than 60 give them an animal and add its value to their score
        if (rand1 >= 60) {
            Animals1.add(AnimalStack.pop());
            Animal TempScore = (Animal) Animals1.remove();
            rand1 = TempScore.getScore() + rand1;
            System.out.printf("Team 1 Final Score: %d\n", rand1);
        }

        //if team 1 score is greater than 60 give them an animal and add its value to their score
        if (rand2 >= 60) {
            Animals2.add(AnimalStack.pop());
            Animal TempScore = (Animal) Animals2.remove();
            rand2 = TempScore.getScore() + rand2;
            System.out.printf("Team 2 Final Score: %d\n", rand2);

            //if score for team 1 is greater than team 1 print team 1 wins and add their objects to winner queue
            if (rand1 > rand2) {
                System.out.println("team 1 wins\n");
                Winners.add(Players1.remove());
                Winners.add(Players1.remove());
                Winners.add(Players1.remove());
                Winners.add(Players1.remove());
                Winners.add(Players1.remove());
                Winners.add(Players1.remove());

            }
            // else print team 2 wins and add their objects to winner queue
            else {
                System.out.println("team 2 wins\n");
                Winners.add(Players2.remove());
                Winners.add(Players2.remove());
                Winners.add(Players2.remove());
                Winners.add(Players2.remove());
                Winners.add(Players2.remove());
                Winners.add(Players2.remove());
            }
            }

        //create and open file
        try {
            File winners;
            FileWriter writer = null;

            winners = new File("C:\\temp\\winners.txt");
            writer = new FileWriter(winners);

            if (winners.createNewFile()) {
                System.out.println("New File created 'winners.txt' : ");
            } else {
                System.out.println("File exists");
            }

        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        //write objects to file and close file
            try {

                FileOutputStream f = new FileOutputStream(new File("C:\\temp\\Winners.txt"));
                ObjectOutputStream o = new ObjectOutputStream(f);

                // Write objects to file
                o.writeObject(Winners);

                o.close();
                f.close();

                FileInputStream fi = new FileInputStream(new File("C:\\temp\\Winners.txt"));
                ObjectInputStream oi = new ObjectInputStream(fi);



                System.out.println("The Object  was succesfully written to a file");

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }


