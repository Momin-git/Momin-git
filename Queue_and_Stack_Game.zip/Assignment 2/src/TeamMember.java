//Team member class with subclasses and corresponding getters and setters

import java.io.Serializable;

abstract class TeamMember implements Serializable {
protected String name;
protected int age;
public String gender;

public abstract void play();
        }

        class Employee extends TeamMember {
            // Getter for name
            public String getName() {
                return name;
            }

            // Setter for name
            public void setName(String newName) {
                this.name = name;
            }

            // Getter for age
            public int getAge() {
                return age;
            }

            // Setter for age
            public void setAge(String newName) {
                this.age = age;
            }

            // Getter for gender
            public String getGender() {
                return name;
            }

            // Setter for gender
            public void setGender(String newName) {
                this.gender = gender;
            }

            @Override
            public void play() {
                System.out.println("an Employee is playing\n");
            } // print a message: an Employee is playing.


        }
class Admin extends TeamMember {
    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String newName) {
        this.name = newName;
    }

    // Getter for age
    public int getAge() {
        return age;
    }

    // Setter for age
    public void setAge(String newName) {
        this.age = age;
    }

    // Getter for gender
    public String getGender() {
        return name;
    }

    // Setter for gender
    public void setGender(String newName) {
        this.gender = gender;
    }

    @Override
    public void play() {
        System.out.println("an Admin is playing\n");
    } // print a message: an Admin is playing.

}
    class Staff extends TeamMember {
        // Getter for name
        public String getName() {
            return name;
        }

        // Setter for name
        public void setName(String newName) {
            this.name = newName;
        }

        // Getter for age
        public int getAge() {
            return age;
        }

        // Setter for age
        public void setAge(String newName) {
            this.age = age;
        }

        // Getter for gender
        public String getGender() {
            return name;
        }

        // Setter for gender
        public void setGender(String newName) {
            this.gender = gender;
        }

        @Override
        public void play() {
            System.out.println("a Staff is playing\n");
        } // print a message: a Staff is playing.


    }
    class Faculty extends TeamMember {
        // Getter for name
        public String getName() {
            return name;
        }

        // Setter for name
        public void setName(String newName) {
            this.name = newName;
        }
        // Getter for age
        public int getAge() {
            return age;
        }

        // Setter for age
        public void setAge(String newName) {
            this.age = age;
        }

        // Getter for gender
        public String getGender() {
            return name;
        }

        // Setter for gender
        public void setGender(String newName) {
            this.gender = gender;
        }
        @Override
        public void play() {
            System.out.println("a Faculty is playing\n");
        } // print a message: a Faculty is playing.


    }
