//declaring Scorable interface
public interface Scoreable {
    int getScore();
}
